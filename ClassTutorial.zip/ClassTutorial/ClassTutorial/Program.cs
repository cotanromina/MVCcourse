﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTutorial
{
    struct EngineStruct
    {

    }
    class Program
    {
        static void Main(string[] args)
        {
            Mercedes mercedes = new Mercedes();
            EngineStruct engine = new EngineStruct();
            ICar car = new Mercedes();
            AbstractCar car2 = new Mercedes();
            Console.WriteLine("This is my first C# project!");
            //Console.WriteLine("Mercedes is " + mercedes.Description);
            //Console.WriteLine("Mercedes costs " + mercedes.Price);
            Console.WriteLine("Mercedes is " + mercedes._description);
            Console.WriteLine("Mercedes costs " + mercedes._price);
            Console.ReadKey();
        }
    }
}
